create database CoffeeCafe

use CoffeeCafe
create table items(
iid int identity(1,1) primary key,
name varchar(250) not null,
Category varchar(250) not null,
price bigint not null
);

Category,name,price

select * from items